var mongoose = require('mongoose');

// User Schema
var UserSchema = mongoose.Schema({
   
    first_name: {
        type: String,
       
    },
    last_name: {
        type: String,
        
    },
    email: {
        type: String,
       
    },
    mobile: {
        type: String,
       
    },
    
    user_group: {
        type: String,
        default: null
    },
     password: {
        type: String,
        
    },

    username: {
        type: String,
        
    },

    image_path: {
        type: String,
        default: "/assets/img/man.png"
        
    },
    type: {
        type: String,
        default: 1
       
    },
    status: {
        type: String,
        enum : ['1','0'],
        default: '1'
    },

    is_admin: {
        type: String,
        enum : [true,false],
        default: false
    },
    deviceToken: {
        type: String,
       
    },
    deviceType: {
        type: String,
       
    },
    online: {
        type: String,
       
    },
    onlineTime: {
        type: String,
        default: null
    },
     userToken: {
        type: String,
        default: null
    },
     isContact: {
        type: String,
        enum : [true,false],
        default: false
    },
    created_at: {
        type: String,
    }
});

var User = module.exports = mongoose.model('User', UserSchema);

