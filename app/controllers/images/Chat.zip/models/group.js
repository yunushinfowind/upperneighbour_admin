var mongoose = require('mongoose');

// Group Schema
var GroupSchema = mongoose.Schema({
   
    group_icon: {
        type: String,
    },
    group_name: {
        type: String,
        
    },
    is_group: {
        type: String,
        enum : [true,false],
        default: false
    },
    friend_name: {
        type: String,
    },
    createdby: {
        type: String,
        default: null
    },
    lastmsgsentby: {
        type: String,
    },

    lastmsgtime: {
        type: String,
    },

    last_msg: {
        type: String,
    },
    timestamp: {
        type: String,
    },
    userLists: {
        type: [],
    },
    status: {
        type: String,
        enum : ['1','0'],
        default: '1'
    },
    last_msg_sender_name: {
        type: String,
    },
    last_msg_type: {
        type: String,
    }
});

var Group = module.exports = mongoose.model('chatRoom', GroupSchema);

