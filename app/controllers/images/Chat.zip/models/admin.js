var mongoose = require('mongoose');

// Admin Schema
var AdminSchema = mongoose.Schema({
   
    name: {
        type: String,
        
    },
    email: {
        type: String,
        
    },
    mobile: {
        type: String,
        
    },
    username: {
        type: String,
        
    },
    password: {
        type: String,
        
    },
    profile_picture: {
        type: String,
        
    },
    created_at: {
        type: String,
        
    },

    created_by: {
        type: String,
        
    },

    updated_by: {
        type: String,
        
    },
    updated_at: {
        type: String,
       
    },
    status: {
        type: String,
        enum : ['active','deactive'],
        default: 'active'
    },

    deleted: {
        type: String,
        enum : ['1','0'],
        default: '1'
    },
    
    
});



var Admin = module.exports = mongoose.model('Admin', AdminSchema);


