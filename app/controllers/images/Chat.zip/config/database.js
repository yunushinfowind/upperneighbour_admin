//const mysql = require('mysql');
//var mysqlModel = require('mysql-model');
module.exports = {
    database: 'mongodb://localhost/web_chat_app'
}

/*module.exports = {
      mysqlConnection : mysql.createConnection({
						host: 'localhost',
						user: 'root',
						password: '',
						database: 'Node_admin_db'
					})
  }*/


 /* module.exports = {
      MyAppModel : mysqlModel.createConnection({
						host: 'localhost',
						user: 'root',
						password: '',
						database: 'WeSound'
					})
  }*/
