var nodemailer = require('nodemailer');

exports.isUser = function(req, res, next) {
    if (req.isAuthenticated()) {
        next();
    } else {
        req.flash('error', 'Please log in.');
        res.redirect('/');
    }
}

exports.isAdmin = function(req, res, next) {
    if (req.isAuthenticated() && res.locals.user.is_admin == true) {
        next();
    } else {

        req.flash('error', 'Please log in as admin.');
        res.redirect('/');
    }
}


exports.transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'anit.infowind@gmail.com',
    pass: 'infowind@123'
  }
});

