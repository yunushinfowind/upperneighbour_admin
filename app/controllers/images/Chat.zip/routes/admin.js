var express = require('express');
var app = express();
var auth = require('../config/auth');
var isUser = auth.isUser;




//*** Get Controller ***//
var AdminCont = require('../controllers/Admin');
//var CategoyCont = require('../controllers/Category');


//******Admin Route *******//
app.get('/',AdminCont.login);
app.post('/login',AdminCont.login_submit);
app.get('/logout',AdminCont.logout);
//app.get('/forgot-password', AdminCont.forgot_password);
//app.post('/reset-password', AdminCont.reset_password);
app.get('/dashboard',isUser, AdminCont.dashboard);
//app.get('/change-password',isAdmin, AdminCont.change_password);
//app.post('/change-password-submit', AdminCont.change_password_submit);
//app.get('/profile',isAdmin,AdminCont.profile);
app.get('/user-list',isUser,AdminCont.user_list);
app.get('/add-user',AdminCont.add_user);
app.post('/submit-user',AdminCont.submit_user);
app.get('/edit-user/:id',AdminCont.edit_user);
app.post('/update-user',AdminCont.update_user);
app.get('/delete-user/:id',AdminCont.delete_user);

// ******** Group Route *******//
app.get('/group-list',isUser,AdminCont.group_list);
app.get('/add-group',isUser,AdminCont.add_group);
app.post('/submit-group',isUser,AdminCont.submit_group);
app.get('/edit-group/:id',isUser,AdminCont.edit_group);
app.post('/update-group',isUser,AdminCont.update_group);

//****** Chat Route *********//


app.get('/private-chat',isUser,AdminCont.private_chat);
app.get('/chat/:id',isUser,AdminCont.chat);

app.post('/add-chat-user',isUser,AdminCont.add_chat_user);



// Exports
module.exports = app;
