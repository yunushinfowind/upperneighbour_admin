var express    = require('express');
var path       = require('path');
var mongoose   = require('mongoose');
var config     = require('./config/database');
var bodyParser = require('body-parser');
var session    = require('express-session');
var expressValidator = require('express-validator');
var fileUpload = require('express-fileupload');
var passport   = require('passport');
var flash      = require('express-flash-messages');
var app        = express();
var ioServer   = require('./socket')(app);

// Connect to db
mongoose.connect(config.database);
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
    console.log('Connected to MongoDB');
});

// Init app

// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
// Set public folder
app.use(express.static(path.join(__dirname, 'public')));

// Express fileUpload middleware
app.use(fileUpload());

// Body Parser middleware
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// Express Session middleware
app.use(session({
    secret: 'keyboard cat',
    resave: true,
    saveUninitialized: true
//  cookie: { secure: true }
}));

// Passport Config
require('./config/passport')(passport);
// Passport Middleware
app.use(passport.initialize());
app.use(passport.session());

app.get('*', function(req,res,next) {
   res.locals.cart = req.session.cart;
   res.locals.user = req.user || null;
  next();
});
app.use(flash())
// Set routes 
var admin = require('./routes/admin.js');
app.use('/', admin);


// Start the server
var port = 8081;

ioServer.listen(port, function () {
    console.log('Server started on port ' + port);
});
