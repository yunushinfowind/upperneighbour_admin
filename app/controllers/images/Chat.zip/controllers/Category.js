var express = require('express');
var app = express();
var passport = require('passport');
var bcrypt = require('bcryptjs');
var fs = require('fs-extra');
var path = require('path');
var dateFormat = require('dateformat');
var auth = require('../config/auth');
var base64 = require('base-64');


 //*************Start Group  Section here ***//

// ****** category List *********//
 exports.category_list = function(req, res ) {
      Category.find('all',{where: "is_active='1'"},function (err, categories) {
         if (err)
            return console.log(err);
        res.render('admin/category/category_list', {
            categories: categories
        });
    });
    
 }

 // ******  Add Category  *********//
 exports.add_category = function(req, res ) {

     res.render('admin/category/add_category');
 }

 // ******  Submit category  Category  *********//
 exports.submit_category = function(req, res ) {
     
    var imageFile = typeof req.files.category_icon !== "undefined" ? req.files.category_icon.name : "";
   
     var category = req.body.category;
     var now = new Date();
     var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");

    
        Category.find('count', {where: "category_name='"+category+"' AND is_active='1'"}, function (err, caegory) {
            if (caegory > 0) {
                req.flash('error', 'Category Already exits.');
                res.redirect('/add-category');                
            } else {
 
                var CatData = new CategoryModel({
                    category_name: category,
                    category_icon_image: imageFile,
                    creation_datetime:Newdate,
                    created_by:req.user.id
                 });

                if (imageFile != "") {
                        var CategoryImage = req.files.category_icon;
                        var path = 'public/uploads/category_images/'+ imageFile;

                       

                        CategoryImage.mv(path, function (err) {
                             console.log(err);
                        });
                    }
                  CatData.save(function (err) {
                            if (err)
                             
                            req.flash('success', 'Category Added Successfully.');
                            res.redirect('/category-list');
                        });
                    }
        });
 }


// ******  edit get  Category data   *********//
 exports.edit_category = function(req, res ) {

   var category_id = base64.decode(req.params.id);

     Category.find('first',{where: "is_active='1' AND id='"+category_id+"'"},function (err, category) {
         if (err)
           console.log(err);
        res.render('admin/category/edit_category', {
            category: category
        });
 });

} 

// update category ******//

exports.update_category = async function(req, res) {
    
    var imageFile = typeof req.files.category_icon !== "undefined" ? req.files.category_icon.name : "";

     var category = req.body.category;
      var category_id = req.body.category_id;
     var category_icon_post = req.body.category_icon_post;
    
     Category.find('count',{where: "category_name='"+category+"' AND is_active='1' AND id !='"+category_id+"'"}, function (err, result) {
           if (err)
              console.log(err);

            if (result > 0 ) {
              req.flash('error', 'Category Name Already Exits.');
              res.redirect('/edit-category/'+category_id);
               
            } else {

     var now = new Date();
     var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");
     if(imageFile!=""){
      var image = imageFile;
     }else{
      var image = category_icon_post;
     }
     var count     = 0;

     var query    = "Update category SET ";
            
                var Data = {
                    category_name   : category,
                    category_icon_image  : image,
                    last_updated_datetime:Newdate,
                    updated_by:req.user.id
          }

            Object.keys(Data)
                .forEach(function eachKey(key) { 

                   if(count!=0){
                        query += " , ";
                    } 
                    
                    if(typeof(Data[key])=='object'){
                        query += key +" = '"+JSON.stringify(Data[key])+"'"; 
                    }else{
                      var str = ''+Data[key]+'';
                        query += '`'+key+'`' +" = '"+str.replace(/'/g, "\\'")+"'"; 
                    }
                     count++;
                   
            });
             query += " WHERE id = "+category_id;

                  if (imageFile != "") {
                        var CategoryImage = req.files.category_icon;
                        var path = 'public/uploads/category_images/'+ imageFile;
                           CategoryImage.mv(path, function (err) {
                             console.log(err);
                        });
                    }

            
               Category.query(query,  function(err, user){
                if(err){
                      req.flash('error', 'Could Not Update Try After sometime.');
                      res.redirect('/edit-category/'+category_id);
                }else{
                    req.flash('success', 'Category Update Successfully.');
                    res.redirect('/category-list');
                }

      });
     }
    });              
 };


 //********** delete category *********//

 exports.delete_category = function(req, res) {
    var category_id = base64.decode(req.params.id);
    var now         = new Date();
    var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");

      var count = 0;
      var query = "Update category SET ";
            
                var adminData = {
                     is_active    :  0,
                     last_updated_datetime:Newdate,
                     updated_by : req.user.id

                  }

            Object.keys(adminData)
                .forEach(function eachKey(key) { 
                    if(count!=0){
                        query += " , ";
                    }
                    if(typeof(adminData[key])=='object'){
                        query += key +" = '"+JSON.stringify(adminData[key])+"'"; 
                    }else{
                        query += key +" = '"+adminData[key]+"'"; 
                    }
                    count++;
            });
             query += " WHERE id = "+category_id;

             console.log(query)

             
               Category.query(query,function(err, user){
                   
                      if(err){
                            req.flash('error', 'Could Not Delete Try After sometime.');
                            res.redirect('/edit-category/'+category_id);
                      }else{
                          req.flash('success', 'Category Deleteed Successfully.');
                          res.redirect('/category-list');
                      }
          });
         
}








 















 

