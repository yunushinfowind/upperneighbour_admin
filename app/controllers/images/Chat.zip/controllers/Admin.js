var express = require('express');
var app = express();
var passport = require('passport');
var bcrypt = require('bcryptjs');
var fs = require('fs-extra');
var path = require('path');
var dateFormat = require('dateformat');
var auth = require('../config/auth');

// Get Users model
var User = require('../models/user');
var Group = require('../models/group');
 
 //******* User Login *********//

 exports.login = function(req, res ) {
     res.render('login');
 }

//***** This randum number genrate****//
 function rand_generate() {
      return Math.floor(Math.random() * 900000) + 100000;
 }

 
//******* login  submit use passport ********//
exports.login_submit =  function (req, res, next) {


    passport.authenticate('local', {
        successRedirect: '/dashboard',
        failureRedirect: '/',
        failureFlash: true
    })(req, res, next);
    
}

exports.logout =  function (req, res) {
    req.logout();
    req.flash('success', 'You are logged out!');
    res.redirect('/');

}


//******* Dashboard********//
 exports.dashboard = function(req, res ) {
     res.render('admin/index');
 }


 //******* forgot password********//
 /*exports.forgot_password = function(req, res ) {
     res.render('admin/forgot_password');
 }*/

 //******* Reset password********//
/* exports.reset_password = function(req, res ) {
      var email = req.body.username;

     User.find('first', {where: "email='"+email+"'"}, async function(err, userInfo) {

         if (userInfo.length==0) {
           req.flash('error', 'Please enter registered email.');
           res.redirect('/forgot-password');
        
       } else {
          const password = rand_generate();
          var newPassword = password;
          const salt  = await bcrypt.genSalt(10);
          const hash  = await bcrypt.hash(""+newPassword+"", salt);

          var message = "Hello :"+userInfo.first_name+"<br>Your New Password Is :"+newPassword;

          send_email(email,message,subject="Forgot Password");

           var query  = "Update users SET password = '"+hash+"' WHERE id = "+userInfo.id;

             User.query(query,function(err, user){
           
              if (user) {
                    req.flash('success', 'Your new password send yur registered email address please check.');
                    res.redirect('/forgot-password');
                } else {
                    req.flash('error', 'Invalid Email Address.');
                    res.redirect('/forgot-password');
                }
           });
         }
      });
 }*/

 //******* change  password get ********//
/* exports.change_password = function(req, res ) {
     res.render('admin/change_password');
 }

 exports.change_password_submit = async function(req, res ) {

    var user_id = req.user.id;
    var old_password = req.body.old_password;
    var current_password = req.body.new_password;
    var con_password    = req.body.con_password;

      User.find('first', {where: "id='"+user_id+"'"}, async function(err, userInfo) {
         if (!userInfo) {
           req.flash('error', 'Old Password not match.');
           res.redirect('/change-password');
         } else {
          const password  = current_password
         // var newPassword = password;
          const salt  = await bcrypt.genSalt(10);
          const hash  = await bcrypt.hash(password, salt);

              bcrypt.compare(old_password, userInfo.password, function (err, isMatch) {
              
                if (isMatch) {
                var query  = "Update users SET password = '"+hash+"' WHERE id = "+userInfo.id;
                  User.query(query,function(err, user){
                 
                   if (user) {
                           req.flash('success', 'Your password updated successfully.');
                           res.redirect('/change-password');
                           
                          } else {
                            req.flash('error', 'Something went worng.');
                            res.redirect('/change-password');
                            
                          }
                      });
                } else {
                  req.flash('error', 'Old Password not match.');
                  res.redirect('/change-password');
                }
             });

         }
      });
   }*/

// ******  User Profile *********//
 /*exports.profile = function(req, res ) {
     res.render('admin/admin_profile');
 }*/


// ******  User List *********//
 exports.user_list = function(req, res ) {
    User.find(function (err, user) {
      console.log(user);
      res.render('admin/users/user_list', {
            users: user});
    })
}

exports.add_user = function(req, res ) {
     res.render('admin/users/add_user');
 }
// ********** Submit user ***************//
 exports.submit_user = function (req, res) {
  
 var imageFile = typeof req.files.user_profile !== "undefined" ? req.files.user_profile.name : "";
  var now = new Date();
  var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");
    User.findOne({username: req.body.username}, function (err, userInfo) {
      console.log(userInfo);
            if (err)
                console.log(err);

            if (userInfo) {
                req.flash('danger', 'Username already exists, choose another!');
                res.redirect('/add-user');
            } else {

              if(imageFile!=""){
                Image = '/uploads/user_profile/' + imageFile;
              }else{
                Image = req.body.old_path;
              }
               

                 var user =   new User ({
                              first_name: req.body.first_name,
                              last_name: req.body.last_name,
                              email: req.body.email,
                              mobile: req.body.mobile_number,
                              username: req.body.username,
                              password: req.body.password,
                              image_path: Image,
                              isContact:false,
                              location:"",
                              lat:"",
                              lang:"",
                              onlineTime:"",
                              deviceToken: "",
                              created_at:Newdate

                       });
                   bcrypt.genSalt(10, function (err, salt) {
                    bcrypt.hash(user.password, salt, function (err, hash) {
                        if (err)
                            console.log(err);

                        user.password = hash;
                      user.save(function(err, user) {

                        if (err) {
                                console.log(err);
                            } else {
                               if (imageFile != "") {
                                  var UserImage = req.files.user_profile;
                                  var path = 'public/uploads/user_profile/' + imageFile;

                                  UserImage.mv(path, function (err) {
                                       console.log(err);
                                  });
                              }


                                req.flash('success', 'Add User Successfully.');
                                res.redirect('/user-list')
                            }
                        });
                      }); 
                    });
                }
           });
}

// **********  Update User *********//
 exports.update_user = function (req, res) {
  
 var imageFile = typeof req.files.user_profile !== "undefined" ? req.files.user_profile.name : "";
  var now = new Date();
  var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");
    User.findOne({username: req.body.username, _id: {'$ne': req.body.user_id}}, function (err, userInfo) {
      console.log(userInfo);
            if (err)
                console.log(err);

            if (userInfo) {
                req.flash('danger', 'Username already exists, choose another!');
                res.redirect('/add-user');
            } else {

              if(imageFile!=""){
                Image = '/uploads/user_profile/' + imageFile;
              }else{
                Image = req.body.old_path;
              }
               

                 var user =   {
                              first_name: req.body.first_name,
                              last_name: req.body.last_name,
                              email: req.body.email,
                              mobile: req.body.mobile_number,
                              username: req.body.username,
                              image_path: Image,
                              isContact:false,
                              location:"",
                              lat:"",
                              lang:"",
                              onlineTime:"",
                              deviceToken: "",
                              created_at:Newdate

                       }

                      User.findOneAndUpdate({_id:req.body.user_id},{$set:user},function(err, user) {

                        if (err) {
                                console.log(err);
                            } else {
                               if (imageFile != "") {
                                  var UserImage = req.files.user_profile;
                                  var path = 'public/uploads/user_profile/' + imageFile;

                                  UserImage.mv(path, function (err) {
                                       console.log(err);
                                  });
                              }


                                req.flash('success', 'Update User Successfully.');
                                res.redirect('/user-list')
                            }
                      });
                    }
                });
             }

//******* Edit User *****//

exports.edit_user = function (req, res) {

        User.findById(req.params.id, function (err, userInfo) {
            if (err) {
                console.log(err);
                res.redirect('/user-list');
            } else {
                    res.render('admin/users/edit_user', {
                             user : userInfo
                        });
                    }
                });
          
}

// *************  Delete User **********//

exports.delete_user = function (req, res) {
  
  var now = new Date();
  var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");
                   var user =   {
                                 status:0
                                }

                      User.findOneAndUpdate({_id:req.params.id},{$set:user},function(err, user) {

                        if (err) {
                                console.log(err);
                            } else {
                              
                                req.flash('success', 'Delete User Successfully.');
                                res.redirect('/user-list')
                            }
                      });
  }
             




 //**** Send email Function *******//

 //********* Group  List **********//
 exports.group_list = function(req, res ) {
    Group.find({is_group:'true'},function (err, group) {
      res.render('admin/group/group_list', {
            groups: group});
    })
}

//**** Add Group *******//
exports.add_group = function (req, res) {

        User.find({status:'1'}, function (err, userInfo) {
             if (err) {
                console.log(err);
             } else {
                    res.render('admin/group/add_group', {
                             users : userInfo
                        });
                    }
                });
          
}

// **********  Update Group Form ***************//
exports.update_group = async function (req, res) {


 var imageFile = typeof req.files.group_icon !== "undefined" ? req.files.group_icon.name : "";
 console.log(imageFile);
  var now = new Date();
  var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");
    Group.findOne({group_name: req.body.group_name, _id: {'$ne': req.body.group_id}}, async function (err, groupInfo) {
     // console.log(groupInfo);
            if (err)
                console.log(err);

            if (groupInfo) {
                req.flash('danger', 'Groupname already exists, choose another!');
                res.redirect('/add-group');
            } else {

              if(imageFile!=""){
                image  = "/uploads/group_icon/"+imageFile;
              }else{
                image  = req.body.old_path;
              }

            var userLists = req.body.userLists;
           
            var UserList  =  await User.find( { _id: { $in: userLists } } ); 

               var record = {
                   "group_icon": image,
                   "group_name": req.body.group_name,
                   "is_group": req.body.is_group,
                   "createdby":req.user.id,
                   "lastmsgsentby": "",
                   "lastmsgtime":Date.now(),
                   "last_msg":"",
                   "timestamp": Date.now(),
                   "userLists":UserList,
                   "status": req.body.status,
                   "last_msg_sender_name": "",
                   "last_msg_type": "",
              };

                
                  Group.findOneAndUpdate({_id:req.body.group_id},{$set:record},function(err, user) {

                        if (err) {
                                console.log(err);
                            } else {
                               if (imageFile != "") {
                                  var UserImage = req.files.group_icon;
                                  var path = 'public/uploads/group_icon/' + imageFile;

                                  UserImage.mv(path, function (err) {
                                       console.log(err);
                                  });
                              }


                                req.flash('success', 'Update Group Successfully.');
                                res.redirect('/group-list')
                            }
                      });
                    }
                });
             }

//******** Edit Group ************//

exports.edit_group = function (req, res) {
   Group.findOne({status:'1',_id:req.params.id}, function (err, gInfo) {
      User.find({status:'1'}, function (err, userInfo) {
             if (err) {
                console.log(err);
             } else {
                    res.render('admin/group/edit_group', {
                             users     : userInfo,
                             groupInfo : gInfo
                        });
                    }
                });
         });
          
}


// **********  Submit Group Form ***************//
exports.submit_group = async function (req, res) {

  

//console.log(req.body);
  
 var imageFile = typeof req.files.group_icon !== "undefined" ? req.files.group_icon.name : "";
  var now = new Date();
  var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");
    Group.findOne({group_name: req.body.group_name}, async function (err, groupInfo) {
     // console.log(groupInfo);
            if (err)
                console.log(err);

            if (groupInfo) {
                req.flash('danger', 'Groupname already exists, choose another!');
                res.redirect('/add-group');
            } else {

            var userLists = req.body.userLists;
           
            var UserList  =  await User.find( { _id: { $in: userLists } } ); 

               var record = new Group({
                   "group_icon": "/uploads/group_icon/"+imageFile,
                   "group_name": req.body.group_name,
                   "is_group": req.body.is_group,
                   "createdby":req.user.id,
                   "lastmsgsentby": "",
                   "lastmsgtime":Date.now(),
                   "last_msg":"",
                   "timestamp": Date.now(),
                   "userLists":UserList,
                   "status": req.body.status,
                   "last_msg_sender_name": "",
                   "last_msg_type": "",
              });

            record.save(function(err, user) {

                        if (err) {
                                console.log(err);
                            } else {
                               if (imageFile != "") {
                                  var UserImage = req.files.group_icon;
                                  var path = 'public/uploads/group_icon/' + imageFile;

                                  UserImage.mv(path, function (err) {
                                       console.log(err);
                                  });
                              }
                              req.flash('success', 'Add Group Successfully.');
                                res.redirect('/group-list')
                            }
                      });
                    }
                });
             }


//*********** Private Chat ***********//

 exports.private_chat = function(req, res ) {
    User.find(function (err, user) {
      Group.find(function (err, Chatroom) { 
      res.render('admin/chat/private_chat', {
                Users: user,
                RoomList: Chatroom,
                room: {}
              });
     })
    })
}

//******** add-chat-user***********//

exports.add_chat_user = async function (req, res) {

//console.log(req.body);
   var userLists = req.body.user_id;
   var UserList  =  await User.findOne( { _id: { $in: userLists } } ); 
  var now = new Date();
  var Newdate = dateFormat(now, "yyyy-mm-dd HH:MM:ss");
  /* Group.find({$and : [{ "createdby" : req.user.id}, {"userLists": {$elemMatch: {"_id":req.body.user_id}}},{"is_group":false}]} ,async function (err, groupInfo) {
      //console.log(groupInfo);
            if (err)
                console.log(err);

            if (groupInfo) {
                var userLists = groupInfo[0];
            } else {
*/

               var record = new Group({
                  "group_name": UserList.first_name+" "+UserList.last_name,
                   "friend_name": req.user.first_name+" "+req.user.last_name,
                   "is_group": false,
                   "createdby":req.user.id,
                   "lastmsgsentby": "",
                   "lastmsgtime":Date.now(),
                   "last_msg":"",
                   "timestamp": Date.now(),
                   "userLists":UserList,
                   "status": req.body.status,
                   "last_msg_sender_name": "",
                   "last_msg_type": "",
              });

                  record.save(function(err, user) {

                        if (err) {
                                console.log(err);
                            } else {
                              
                              req.flash('success', 'Add chat member Successfully.');
                                res.redirect('/private-chat')
                            }
                      });
                 /*   }
                });*/
             }

// ******** chat by room id **********//

 exports.chat = function(req, res ) {
    User.find(function (err, user) {
      Group.findOne({_id:req.params.id},function (err, room) { 
      Group.find(function (err, Chatroom) { 
      res.render('admin/chat/private_chat', {
                Users: user,
                RoomList: Chatroom,
                room: room
              });
        })
     })
    })
}



//*********  Send email Function ***********//

function send_email(email,message,subject){
  const transporter = auth.transporter;
    var mailOptions = {
      from: 'anit.infowind@gmail.com',
      to: email,
      subject: subject,
      html: message
    };

    transporter.sendMail(mailOptions, function(error, info){
      if (error) {
        return false
      } else {
        return true;
        //console.log('Email sent: ' + info.response);
      }
    });
}

 







 















 

